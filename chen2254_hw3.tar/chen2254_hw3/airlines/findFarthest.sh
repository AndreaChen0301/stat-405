#!/bin/bash
data_dir="data"

# Check if the data directory exists
if [ ! -d "$data_dir" ]; then
    echo "Data directory does not exist."
    exit 1
fi

# Combine all MSN*.csv files into allMSN.csv
cat "$data_dir"/MSN*.csv > "$data_dir/allMSN.csv"

sort -t, -k5,5nr "$data_dir"/allMSN.csv | head -n 1 | cut -d, -f3-5 > farthest.txt

echo "The farthest flight details have been saved to farthest.txt."
