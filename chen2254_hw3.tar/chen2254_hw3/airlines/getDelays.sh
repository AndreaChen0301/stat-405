#!/bin/bash

# Define the input and output files
input_file="./data/allMSN.csv"
output_file="delays.txt"

module load R/R-3.6.1

# Execute R commands via Rscript
Rscript -e " \
data <- read.csv('$input_file', header=FALSE); \
average_delays <- tapply(data[,2], data[,1], mean, na.rm=TRUE); \
days <- c('Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'); \
ordered_delays <- setNames(average_delays[order(as.numeric(names(average_delays)))], days); \
ordered_delays_rounded <- round(ordered_delays, 1); \
df <- data.frame(t(ordered_delays_rounded)); \
colnames(df) <- names(ordered_delays_rounded); \
write.table(df, file='$output_file', quote=FALSE, row.names=FALSE, col.names=TRUE, sep=' '); \
"

echo "Average delays by day of week saved to $output_file."
