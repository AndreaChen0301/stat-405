#!/bin/bash

# Ensure the slurmout directory exists
mkdir -p slurmout

# Submit dataPrep.sh
jobId1=$(sbatch --array=1987-2008 \
		--output="slurmout/slurm-%j.out" \
                dataPrep.sh)

jobId1=$(echo $jobId1 | sed 's/Submitted batch job //')

# Submit findFarthest.sh, ensuring it runs after dataPrep.sh completes successfully
jobId2=$(sbatch --output="slurmout/slurm-%j.out" \
                --dependency=afterok:$jobId1 \
                findFarthest.sh)
jobId2=$(echo $jobId2 | sed 's/Submitted batch job //')

# Submit getDelays.sh, ensuring it runs after findFarthest.sh completes successfully
jobId3=$(sbatch --output="slurmout/slurm-%j.out" \
                --dependency=afterok:$jobId2 \
                getDelays.sh)
jobId3=$(echo $jobId3 | sed 's/Submitted batch job //')

echo "Submitted dataPrep.sh with job ID $jobId1"
echo "Submitted findFarthest.sh with job ID $jobId2, depending on completion of dataPrep.sh"
echo "Submitted getDelays.sh with job ID $jobId3, depending on completion of findFarthest.sh"
