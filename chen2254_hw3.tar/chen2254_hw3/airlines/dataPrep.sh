#!/bin/bash

mkdir -p ./data

year=$SLURM_ARRAY_TASK_ID

# Download the dataset
wget -O ./data/$year.csv.bz2 http://pages.stat.wisc.edu/~jgillett/DSCP/HPC/airlines/$year.csv.bz2 || exit 1

cd ./data

# Unzip the dataset
bzip2 -d $year.csv.bz2 || exit 1

cd ..

awk -F',' 'BEGIN {OFS=","} $17 == "MSN" {print $4, $16, $17, $18, $19}' ./data/$year.csv > ./data/MSN$year.csv || exit 1

echo "Finished processing year: $year"
