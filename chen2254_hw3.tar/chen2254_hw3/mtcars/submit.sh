#!/bin/bash

JobId1=$(sbatch getData.sh)
JobId1=$(echo $JobId1 | sed 's/Submitted batch job //')

JobId2=$(sbatch --array=1-3 \
		--dependency=afterok:$JobId1 \
	        jobArray.sh)
JobId2=$(echo $JobId2 | sed 's/Submitted batch job //')

JobId3=$(sbatch --dependency=afterok:$JobId2 \
		findLightest.sh)
JobId3=$(echo $JobId3 | sed 's/Submitted batch job //')

echo "Submission complete. getDataJobId: $JobId1, jobArrayJobId: $JobId2, findLighestJobId: $JobId3"
