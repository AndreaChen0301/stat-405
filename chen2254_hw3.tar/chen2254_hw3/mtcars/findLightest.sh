#!/bin/bash

cat out1.csv out2.csv out3.csv | sort -n | head -n 1 > out

