#!/bin/bash

n=$SLURM_ARRAY_TASK_ID

inputFile="mtcars${n}.csv"
outputFile="out${n}.csv"

cut -d, -f7,11 "$inputFile" | awk -F, 'NR > 1 && $2 == 3 {print $1}' > "$outputFile"

echo "Processed $inputFile and saved results to $outputFile."
